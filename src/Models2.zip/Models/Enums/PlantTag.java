package Models.Enums;

public enum PlantTag {
    DAY,
    NIGHT,
    SHROOM,
    WRAMP_UP,
    PEA,
    ICE,
    FIRE,
    STACK,
    CHARGE,
    MAGIC,
    POISON,
    WATER,
    AOE,
    TRAP,
    MOVE_ZOMBIES,
    SUN,
    EXPLOSIVE;
}
