package Models.Enums;

public enum PlantCategory {
    SUN_PRODUCER,
    SHOOTER,
    HOMING,
    STRIKE_THROUGH,
    LOBBER,
    EXPLOSIVE,
    MELEE,
    WALL_NUT,
    MODIFIER;
}
